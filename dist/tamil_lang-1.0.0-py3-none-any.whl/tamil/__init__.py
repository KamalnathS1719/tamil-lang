"""
Tamil Programming Language Package

Author: Kamalnath.S
Email: kamalnath9443348610@gmail.com
"""

from .PowerFullInterpreter import PowerFullInterpreter
